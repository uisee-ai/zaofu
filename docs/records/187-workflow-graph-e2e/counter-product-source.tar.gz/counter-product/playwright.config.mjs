import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests/e2e',
  workers: 1,
  retries: 0,
  timeout: 60_000,
  outputDir: 'artifacts/evidence/counter/browser/results',
  reporter: [
    ['list'],
    ['json', { outputFile: 'artifacts/evidence/counter/browser/report.json' }],
  ],
  use: { baseURL: 'http://localhost:4173', browserName: 'chromium' },
  webServer: {
    command: 'node scripts/serve.mjs --host 0.0.0.0 --port 4173',
    url: 'http://localhost:4173',
    reuseExistingServer: false,
    timeout: 15_000,
  },
});
