# 187-counter

原生 HTML/CSS/JavaScript 计数器。打开后为 0；“加一”增加 1，“减一”最少减至 0，“归零”恢复为 0。刷新页面重新从 0 开始。

## 启动

需要 Node.js ≥22。在仓库根目录运行：

```bash
node scripts/serve.mjs --host 0.0.0.0 --port 4173
```

浏览器访问 <http://localhost:4173>。也可用 `npm start` 启动；Ctrl+C 停止。服务只返回静态资源，没有计数 API 或业务后端。页面没有 CDN、网络字体或运行时依赖，无需构建。部署时只需提供 `index.html`、`src/app.mjs` 和 `src/counter.mjs`。

## 安装与验证

以下命令均在仓库根目录执行。锁文件固定测试依赖 `@playwright/test` 为 1.56.1；安装需要 npm registry 网络访问。

```bash
timeout 180s npm ci
node --test tests/counter.test.mjs
node scripts/check-static.mjs
```

`npm test` 对应 `node --test tests/counter.test.mjs`，覆盖六组计数行为。`npm run lint` 对应 `node scripts/check-static.mjs`，检查脚本语法、HTML/模块接线、静态资源、依赖和运行文档，并生成 `artifacts/evidence/counter/static.json`。

浏览器验证需要 Linux Docker、当前用户可访问的 daemon，以及可下载的 `mcp/playwright:latest` 镜像与 Chromium。先停止手动启动的 4173 服务；测试自行启停同一入口，端口被占用时拒绝复用旧服务。运行精确命令：

```bash
docker run --rm --network host --user "$(id -u):$(id -g)" --entrypoint bash -v "$PWD:/work" -w /work -e PLAYWRIGHT_BROWSERS_PATH=0 mcp/playwright:latest -lc 'set -euo pipefail; timeout 180s ./node_modules/.bin/playwright install chromium; ./node_modules/.bin/playwright test --config playwright.config.mjs'
```

容器内的 `npm run test:e2e` 对应 `playwright test --config playwright.config.mjs`。测试在 1280×720 和 390×844 视口逐步验证初始值、加减、零下限、重复归零和混合操作；同时检查卡片居中、按钮无重叠、无页面异常或业务/第三方网络请求。

成功执行后，`artifacts/evidence/counter/browser/` 包含 `report.json`、`desktop-before.png`（0）、`desktop-after.png`（1）、`mobile.png` 和 `trace.zip`。该目录是合同规定的当前运行输出，由同级 `.gitignore` 忽略；重复执行会覆盖报告时间、trace 等内容，不应将其直接加入版本控制。截图和 trace 仅由真实浏览器执行生成；Docker 权限失败不代表浏览器验收通过，应由环境责任人恢复访问后重跑原命令。

交接时，将完整运行输出复制到新的 `artifacts/evidence/counter/rework-<attempt>/<run>/browser/` 目录，保存原命令日志、退出码、执行提交和文件摘要，并让收据引用这份不可变副本。已有历史浏览器证据位于 `artifacts/evidence/counter/history/<evidence-commit>/browser/`，原路径与归档路径的映射见 `history/index.json`。不要覆盖已有归档；门禁完成后用 `git diff --exit-code HEAD --` 确认所有已跟踪文件未变。

## 手动演示

打开页面，从 0 依次点击“加一、加一、减一、归零、减一、加一”，数值应依次为 **1、2、1、0、0、1**。零值时仍可点击减一；规则模块自身保护下限。三个按钮也支持标准 Tab 焦点和 Enter/空格操作。

## 文件与证据

- `src/counter.mjs`：导出 `INITIAL_COUNT` 和纯函数 `transition(count, action)`，页面和单测共用。
- `src/app.mjs`：保存单个页面状态，绑定一次事件并立即更新显示。
- `scripts/serve.mjs`：仅提供入口和两个模块，拒绝其他路径及写入请求。
- `tests/counter.test.mjs`：六组 Node 行为测试；`tests/e2e/counter.spec.mjs`：真实浏览器旅程。
- `artifacts/evidence/counter/`：本次执行日志与收据；后续验收以目标提交和实际执行结果为准。

RED 的占位模块保存在 `artifacts/evidence/counter/red-counter.mjs`，原始断言失败见 `unit-red.tap.gz`（gzip 无损原始日志）。可在临时副本中替换 `src/counter.mjs` 后执行相同单测命令复现；不要覆盖工作中的生产模块。`NODE_OPTIONS=--test-reporter=tap` 只用于收集 TAP 格式日志，不改变断言。

用 `gzip -dc artifacts/evidence/counter/unit-red.tap.gz` 查看完整原始日志。三份日志的解压摘要、原 Git blob 引用及压缩摘要记录在 `artifacts/evidence/counter/rework-4/storage-migration.json`；包括尾随空格在内的原始字节均保留。
