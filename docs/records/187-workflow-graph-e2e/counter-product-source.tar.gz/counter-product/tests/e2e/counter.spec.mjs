import { test, expect } from '@playwright/test';
import { mkdir, readFile } from 'node:fs/promises';

const evidence = 'artifacts/evidence/counter/browser';

test('双视口真实计数旅程、居中卡片和纯静态运行', async ({ page, context }) => {
  await mkdir(evidence, { recursive: true });
  const errors = [];
  const forbiddenRequests = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.on('console', (message) => { if (message.type() === 'error') errors.push(message.text()); });
  await context.route('**/*', async (route) => {
    const request = route.request();
    const url = new URL(request.url());
    if (url.origin !== 'http://localhost:4173' ||
        !['/', '/src/app.mjs', '/src/counter.mjs'].includes(url.pathname) ||
        !['document', 'script'].includes(request.resourceType()) || request.method() !== 'GET') {
      forbiddenRequests.push(request.url());
      await route.abort();
    } else await route.continue();
  });
  await context.routeWebSocket(/.*/, (socket) => {
    forbiddenRequests.push(socket.url());
    socket.close();
  });
  await context.tracing.start({ screenshots: true, snapshots: true, sources: true });
  try {
    for (const viewport of [{ width: 1280, height: 720 }, { width: 390, height: 844 }]) {
      const desktop = viewport.width === 1280;
      await test.step(`${viewport.width}×${viewport.height}`, async () => {
        await page.setViewportSize(viewport);
        await page.goto('/');
        const count = page.locator('#count');
        const plus = page.getByRole('button', { name: '加一', exact: true });
        const minus = page.getByRole('button', { name: '减一', exact: true });
        const reset = page.getByRole('button', { name: '归零', exact: true });
        const click = async (button, expected) => {
          await button.click();
          await expect(count).toHaveText(String(expected));
          expect(Number(await count.textContent())).toBeGreaterThanOrEqual(0);
        };
        await test.step('AC-INITIAL / AC-CARD: 初值、可见文案、居中及无遮挡', async () => {
          await expect(count).toHaveText('0');
          await expect(reset).toHaveCount(1);
          await expect(reset).toHaveText('归零');
          await expect(page.getByRole('button')).toHaveCount(3);
          const boxes = [];
          for (const locator of [count, plus, minus, reset]) {
            await expect(locator).toBeVisible();
            const box = await locator.boundingBox();
            expect(box).not.toBeNull();
            expect(box.x).toBeGreaterThanOrEqual(0);
            expect(box.y).toBeGreaterThanOrEqual(0);
            expect(box.x + box.width).toBeLessThanOrEqual(viewport.width);
            expect(box.y + box.height).toBeLessThanOrEqual(viewport.height);
            boxes.push(box);
          }
          for (const button of [plus, minus, reset]) await expect(button).toBeEnabled();
          for (let i = 0; i < boxes.length; i++) {
            for (let j = i + 1; j < boxes.length; j++) {
              const a = boxes[i], b = boxes[j];
              expect(a.x + a.width <= b.x || b.x + b.width <= a.x ||
                a.y + a.height <= b.y || b.y + b.height <= a.y).toBe(true);
            }
          }
          const card = await page.getByRole('main').boundingBox();
          expect(Math.abs(card.x + card.width / 2 - viewport.width / 2)).toBeLessThanOrEqual(8);
          expect(Math.abs(card.y + card.height / 2 - viewport.height / 2)).toBeLessThanOrEqual(8);
          await page.screenshot({ path: `${evidence}/${desktop ? 'desktop-before' : 'mobile'}.png` });
        });
        await test.step('AC-INCREMENT: 两次加一与前后截图', async () => {
          await click(plus, 1);
          if (desktop) {
            await page.screenshot({ path: `${evidence}/desktop-after.png` });
            expect((await readFile(`${evidence}/desktop-before.png`))
              .equals(await readFile(`${evidence}/desktop-after.png`))).toBe(false);
          }
          await click(plus, 2);
        });
        await test.step('AC-DECREMENT / AC-FLOOR: 正数减一及连续零值减一', async () => {
          await click(minus, 1);
          await click(minus, 0);
          for (let i = 0; i < 5; i++) await click(minus, 0);
          await page.reload();
          await expect(count).toHaveText('0');
          for (let i = 0; i < 5; i++) await click(minus, 0);
        });
        await test.step('AC-RESET: 零值、正数及重复归零后再加一', async () => {
          await click(reset, 0);
          for (const expected of [1, 2, 3]) await click(plus, expected);
          await click(reset, 0);
          await click(reset, 0);
          await click(plus, 1);
        });
        await test.step('AC-SEQUENCE: 混合操作的每一步', async () => {
          await page.reload();
          await expect(count).toHaveText('0');
          for (const [button, expected] of [[plus, 1], [plus, 2], [minus, 1], [reset, 0], [minus, 0], [plus, 1]]) {
            await click(button, expected);
          }
        });
      });
    }
    await test.step('AC-STATIC / AC-RUN: 无页面错误、业务请求或外部资源', async () => {
      expect(errors).toEqual([]);
      expect(forbiddenRequests).toEqual([]);
    });
  } finally {
    await context.tracing.stop({ path: `${evidence}/trace.zip` });
  }
});
