import test from 'node:test';
import assert from 'node:assert/strict';
import { INITIAL_COUNT, transition } from '../src/counter.mjs';

test('AC-INITIAL: 新状态为 0', () => {
  assert.equal(INITIAL_COUNT, 0);
});

test('AC-INCREMENT: 从 0 连续加一得到 1、2', () => {
  let count = INITIAL_COUNT;
  count = transition(count, 'increment');
  assert.equal(count, 1);
  count = transition(count, 'increment');
  assert.equal(count, 2);
});

test('AC-DECREMENT: 从 2 连续减一得到 1、0', () => {
  let count = transition(transition(INITIAL_COUNT, 'increment'), 'increment');
  assert.equal(count, 2);
  count = transition(count, 'decrement');
  assert.equal(count, 1);
  count = transition(count, 'decrement');
  assert.equal(count, 0);
});

test('AC-FLOOR: 初始 0 及正数减至 0 后连续五次减一均为 0', () => {
  let count = INITIAL_COUNT;
  for (let i = 0; i < 5; i++) {
    count = transition(count, 'decrement');
    assert.equal(count, 0);
  }
  count = transition(count, 'increment');
  assert.equal(count, 1);
  count = transition(count, 'decrement');
  assert.equal(count, 0);
  for (let i = 0; i < 5; i++) {
    count = transition(count, 'decrement');
    assert.equal(count, 0);
  }
});

test('AC-RESET: 0 和正数均可重复归零，归零后加一得到 1', () => {
  assert.equal(transition(INITIAL_COUNT, 'reset'), 0);
  let count = INITIAL_COUNT;
  for (const expected of [1, 2, 3]) {
    count = transition(count, 'increment');
    assert.equal(count, expected);
  }
  count = transition(count, 'reset');
  assert.equal(count, 0);
  count = transition(count, 'reset');
  assert.equal(count, 0);
  count = transition(count, 'increment');
  assert.equal(count, 1);
});

test('AC-SEQUENCE: 加、加、减、归零、减、加逐步得到 1、2、1、0、0、1', () => {
  let count = INITIAL_COUNT;
  for (const [action, expected] of [
    ['increment', 1], ['increment', 2], ['decrement', 1],
    ['reset', 0], ['decrement', 0], ['increment', 1],
  ]) {
    count = transition(count, action);
    assert.equal(count, expected);
  }
});
