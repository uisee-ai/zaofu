export const INITIAL_COUNT = 0;

export function transition(count, action) {
  switch (action) {
    case 'increment': return count + 1;
    case 'decrement': return Math.max(0, count - 1);
    case 'reset': return INITIAL_COUNT;
    default: return count;
  }
}
