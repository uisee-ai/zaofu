import { INITIAL_COUNT, transition } from './counter.mjs';

let count = INITIAL_COUNT;
const display = document.querySelector('#count');
display.textContent = String(count);

for (const button of document.querySelectorAll('button[data-action]')) {
  button.addEventListener('click', () => {
    count = transition(count, button.dataset.action);
    display.textContent = String(count);
  });
}
