import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { parseArgs } from 'node:util';

const { values } = parseArgs({ options: {
  host: { type: 'string', default: '0.0.0.0' },
  port: { type: 'string', default: '4173' },
} });
const root = new URL('../', import.meta.url);
const resources = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/index.html', ['index.html', 'text/html; charset=utf-8']],
  ['/src/app.mjs', ['src/app.mjs', 'text/javascript; charset=utf-8']],
  ['/src/counter.mjs', ['src/counter.mjs', 'text/javascript; charset=utf-8']],
]);

const server = createServer(async (request, response) => {
  if (!['GET', 'HEAD'].includes(request.method)) {
    response.writeHead(405, { Allow: 'GET, HEAD' }).end();
    return;
  }
  const resource = resources.get(request.url.split('?')[0]);
  if (!resource) {
    response.writeHead(404).end('Not found');
    return;
  }
  try {
    const body = await readFile(new URL(resource[0], root));
    response.writeHead(200, { 'Content-Type': resource[1], 'Cache-Control': 'no-store' });
    response.end(request.method === 'HEAD' ? undefined : body);
  } catch (error) {
    console.error(error);
    response.writeHead(500).end('Unable to read static resource');
  }
});
server.on('error', (error) => { console.error(error); process.exitCode = 1; });
server.listen(Number(values.port), values.host, () => {
  console.log(`计数器已启动：http://${values.host}:${values.port}`);
});
