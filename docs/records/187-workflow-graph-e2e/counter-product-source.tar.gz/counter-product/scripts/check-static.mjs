import assert from 'node:assert/strict';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';

const root = new URL('../', import.meta.url);
const read = (path) => readFile(new URL(path, root), 'utf8');
const checks = [];
const sources = {};
function check(id, assertion) {
  try { assertion(); checks.push({ id, status: 'passed' }); }
  catch (error) { checks.push({ id, status: 'failed', message: error.message }); }
}

try {
  for (const path of ['index.html', 'src/app.mjs', 'src/counter.mjs', 'scripts/serve.mjs',
    'scripts/check-static.mjs', 'tests/counter.test.mjs', 'tests/e2e/counter.spec.mjs',
    'playwright.config.mjs', 'package.json', 'package-lock.json', 'README.md']) {
    sources[path] = await read(path);
    if (path.endsWith('.mjs')) check(`syntax:${path}`, () => {
      const result = spawnSync(process.execPath, ['--check', new URL(path, root).pathname], { encoding: 'utf8' });
      assert.equal(result.status, 0, result.stderr);
    });
  }
  const html = sources['index.html'];
  const app = sources['src/app.mjs'];
  const pkg = JSON.parse(sources['package.json']);
  const lock = JSON.parse(sources['package-lock.json']);
  const readme = sources['README.md'];
  check('native-entry-and-card', () => {
    assert.match(html, /<html lang="zh-CN">/);
    assert.match(html, /<meta name="viewport"/);
    assert.match(html, /<style>[\s\S]+place-items:\s*center[\s\S]+<\/style>/);
    assert.match(html, /<main class="card"/);
    assert.match(html, /<output\b[^>]*id="count"[^>]*>0<\/output>/);
    assert.match(html, /<script type="module" src="\.\/src\/app\.mjs"><\/script>/);
    assert.equal([...html.matchAll(/<script\b/g)].length, 1);
  });
  check('visible-actions-and-production-wiring', () => {
    assert.equal([...html.matchAll(/<button\b/g)].length, 3);
    for (const [action, label] of [['increment', '加一'], ['decrement', '减一'], ['reset', '归零']]) {
      assert.match(html, new RegExp(`<button[^>]*data-action="${action}"[^>]*>${label}</button>`));
    }
    assert.match(app, /import\s*\{\s*INITIAL_COUNT,\s*transition\s*\}\s*from\s*'\.\/counter\.mjs'/);
    assert.match(app, /querySelector\('#count'\)/);
    assert.match(app, /addEventListener\('click'/);
    assert.match(app, /count = transition\(count, button\.dataset\.action\)/);
    assert.match(app, /display\.textContent = String\(count\)/);
  });
  check('local-static-resources-only', () => {
    for (const match of html.matchAll(/(?:src|href)="([^"]+)"/g)) {
      assert.ok(['./src/app.mjs', 'data:,'].includes(match[1]), `Unexpected resource: ${match[1]}`);
    }
    for (const path of ['index.html', 'src/app.mjs', 'src/counter.mjs']) {
      assert.doesNotMatch(sources[path], /\b(fetch|XMLHttpRequest|WebSocket|EventSource|sendBeacon)\b|https?:\/\/|@import|url\(/);
    }
    assert.deepEqual(Object.keys(pkg.dependencies ?? {}), []);
    assert.deepEqual(pkg.devDependencies, { '@playwright/test': '1.56.1' });
    assert.equal(lock.packages['node_modules/@playwright/test'].version, '1.56.1');
  });
  check('documented-root-commands', () => {
    assert.equal(pkg.scripts.start, 'node scripts/serve.mjs --host 0.0.0.0 --port 4173');
    assert.equal(pkg.scripts.test, 'node --test tests/counter.test.mjs');
    assert.equal(pkg.scripts.lint, 'node scripts/check-static.mjs');
    assert.equal(pkg.scripts['test:e2e'], 'playwright test --config playwright.config.mjs');
    for (const command of Object.values(pkg.scripts)) assert.ok(readme.includes(command), command);
    assert.ok(readme.includes('timeout 180s npm ci'));
    assert.ok(readme.includes('http://localhost:4173'));
  });
} catch (error) {
  checks.push({ id: 'read-inputs', status: 'failed', message: error.message });
}

const passed = checks.every(({ status }) => status === 'passed');
const report = { command: 'node scripts/check-static.mjs', status: passed ? 'passed' : 'failed', checks,
  files: Object.entries(sources).map(([path, content]) => ({ path, sha256: createHash('sha256').update(content).digest('hex') })) };
const evidence = new URL('artifacts/evidence/counter/', root);
await mkdir(evidence, { recursive: true });
await writeFile(new URL('static.json', evidence), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
process.exitCode = passed ? 0 : 1;
